regedit /e DrEdit.reg HKEY_CURRENT_USER\Software\DrHTML
